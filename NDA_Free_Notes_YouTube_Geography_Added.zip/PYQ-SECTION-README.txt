NDA ORIGINAL YEAR-WISE PYQ SECTION

Updated page: nda-5-year-pyqs.html
Includes year/session-wise direct PDF buttons for official UPSC NDA & NA Mathematics and GAT papers, 2021–2025, plus official listing/archive fallback links.

To publish on Netlify: extract this ZIP, then deploy the extracted website folder that contains index.html (or upload the extracted site files through Netlify manual deploy). This creates the deployable files only; it does not publish to your Netlify account automatically.
