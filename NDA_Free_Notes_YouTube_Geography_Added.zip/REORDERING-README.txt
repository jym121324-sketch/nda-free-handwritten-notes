Homepage sections are arranged in this order: 1) PYQs, 2) 1,000 MCQs, 3) 2D Image Notes, 4) Free Notes, then the remaining study sections. Navigation links were reordered too.

To publish: extract this ZIP and deploy the folder containing index.html to your Netlify site. This ZIP does not automatically update the live website.
